/* ==========================================================
   NEXUS FORGE — shared data + behavior
========================================================== */

/* ---------- ICONS (abstract geometric marks — not game logos) ---------- */
const ICONS = {
  smash:   `<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="18" stroke="currentColor" stroke-width="2.5"/><path d="M16 24L32 16V32L16 24Z" fill="currentColor"/></svg>`,
  brawlhalla: `<svg viewBox="0 0 48 48" fill="none"><path d="M24 6L40 16V32L24 42L8 32V16L24 6Z" stroke="currentColor" stroke-width="2.5"/></svg>`,
  ror2:    `<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="4" fill="currentColor"/><path d="M24 4V16M24 32V44M4 24H16M32 24H44M10 10L18 18M30 30L38 38M38 10L30 18M18 30L10 38" stroke="currentColor" stroke-width="2.2"/></svg>`,
  borderlands: `<svg viewBox="0 0 48 48" fill="none"><path d="M24 8L38 20V38H10V20L24 8Z" stroke="currentColor" stroke-width="2.5"/><path d="M18 38V26H30V38" stroke="currentColor" stroke-width="2.5"/></svg>`,
  skyrim:  `<svg viewBox="0 0 48 48" fill="none"><path d="M24 5L32 20H26V43H22V20H16L24 5Z" fill="currentColor"/></svg>`,
  fallout: `<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="17" stroke="currentColor" stroke-width="2.5"/><circle cx="24" cy="24" r="5" fill="currentColor"/><path d="M24 4V11M24 37V44M4 24H11M37 24H44" stroke="currentColor" stroke-width="2.5"/></svg>`,
  re:      `<svg viewBox="0 0 48 48" fill="none"><rect x="10" y="10" width="28" height="28" rx="5" stroke="currentColor" stroke-width="2.5"/><path d="M18 24H30M24 18V30" stroke="currentColor" stroke-width="2.5"/></svg>`,
  ggs:     `<svg viewBox="0 0 48 48" fill="none"><path d="M24 6L44 24L24 42L4 24L24 6Z" stroke="currentColor" stroke-width="2.5"/><circle cx="24" cy="24" r="5" fill="currentColor"/></svg>`,
  sonic:   `<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="14" stroke="currentColor" stroke-width="2.5"/><circle cx="24" cy="24" r="4" fill="currentColor"/></svg>`,
  palworld:`<svg viewBox="0 0 48 48" fill="none"><path d="M24 8C14 8 8 16 8 26C8 36 16 40 24 40C32 40 40 36 40 26C40 16 34 8 24 8Z" stroke="currentColor" stroke-width="2.5"/><circle cx="18" cy="24" r="2.4" fill="currentColor"/><circle cx="30" cy="24" r="2.4" fill="currentColor"/></svg>`,
  rivals:  `<svg viewBox="0 0 48 48" fill="none"><path d="M8 24H20L24 10L28 38L32 24H40" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round"/></svg>`,

  character:`<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="16" r="8" stroke="currentColor" stroke-width="2.5"/><path d="M8 42C8 32 15 27 24 27C33 27 40 32 40 42" stroke="currentColor" stroke-width="2.5"/></svg>`,
  moveset: `<svg viewBox="0 0 48 48" fill="none"><path d="M8 40L28 20M28 20L23 8L40 12L28 20Z" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round"/></svg>`,
  skin:    `<svg viewBox="0 0 48 48" fill="none"><circle cx="18" cy="30" r="4" fill="currentColor"/><circle cx="30" cy="18" r="4" fill="currentColor"/><circle cx="30" cy="34" r="4" fill="currentColor"/><path d="M8 12C16 8 32 8 40 16C34 24 12 24 8 12Z" stroke="currentColor" stroke-width="2.2"/></svg>`,
  ui:      `<svg viewBox="0 0 48 48" fill="none"><rect x="6" y="10" width="36" height="28" rx="4" stroke="currentColor" stroke-width="2.5"/><path d="M6 18H42" stroke="currentColor" stroke-width="2.5"/></svg>`,
  anim:    `<svg viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="17" stroke="currentColor" stroke-width="2.5"/><path d="M20 16L32 24L20 32V16Z" fill="currentColor"/></svg>`,
  bug:     `<svg viewBox="0 0 48 48" fill="none"><rect x="16" y="16" width="16" height="20" rx="8" stroke="currentColor" stroke-width="2.5"/><path d="M16 22H6M32 22H42M16 32H6M32 32H42M24 16V8M18 12L14 8M30 12L34 8" stroke="currentColor" stroke-width="2.2"/></svg>`,
};

/* ---------- FEATURED GAMES ---------- */
const GAMES = [
  { id:'smash',      name:'Smash Ultimate',    color:'#ff3b6e', icon:ICONS.smash },
  { id:'brawlhalla',  name:'Brawlhalla',        color:'#F97316', icon:ICONS.brawlhalla },
  { id:'ror2',        name:'Risk of Rain 2',    color:'#a855f7', icon:ICONS.ror2 },
  { id:'borderlands', name:'Borderlands',       color:'#facc15', icon:ICONS.borderlands },
  { id:'skyrim',      name:'Skyrim',            color:'#3B82F6', icon:ICONS.skyrim },
  { id:'fallout',     name:'Fallout',           color:'#7dd956', icon:ICONS.fallout },
  { id:'re',          name:'Resident Evil',     color:'#dc2626', icon:ICONS.re },
  { id:'ggs',         name:'Guilty Gear Strive',color:'#fb7185', icon:ICONS.ggs },
  { id:'sonic',       name:'Sonic',             color:'#22d3ee', icon:ICONS.sonic },
  { id:'palworld',    name:'Palworld',          color:'#86efac', icon:ICONS.palworld },
  { id:'rivals',      name:'Marvel Rivals',     color:'#f43f5e', icon:ICONS.rivals },
];

/* ---------- WHAT I CREATE ---------- */
const CREATE_ITEMS = [
  { icon:ICONS.character, title:'Custom Characters', desc:'Bringing original or cross-game characters in as fully playable additions.' },
  { icon:ICONS.moveset,   title:'Custom Movesets',    desc:'Unique attacks, abilities, and combat feel built around the character.' },
  { icon:ICONS.skin,      title:'Skins',              desc:'Outfits, recolors, armor sets, and weapon reskins.' },
  { icon:ICONS.ui,        title:'UI Design',          desc:'Portraits, CSS, stock icons, and victory screens that match the base game.' },
  { icon:ICONS.anim,      title:'Animations',         desc:'Retargeting, editing, and from-scratch animation work.' },
  { icon:ICONS.bug,       title:'Bug Fixes',          desc:'Crash fixes, compatibility patches, and clean installation support.' },
];

/* ---------- PROJECTS ---------- */
const PROJECTS = [
  {
    id:'lich-king', title:'Lich King', game:'smash', gameName:'Smash Ultimate',
    desc:'Full custom fighter import with a unique moveset built around ice and undeath themes, plus matching UI.',
    tags:['Character Import','Moveset','UI'],
    software:['Smash Forge','Blender','Photoshop'],
    materials:['Custom PBR texture set','Emissive frost shader'],
    animations:['12 new animations','Retargeted base skeleton'],
    c1:'#3B82F6', c2:'#0f2a63', icon:ICONS.smash,
  },
  {
    id:'twilight-sparkle', title:'Twilight Sparkle', game:'brawlhalla', gameName:'Brawlhalla',
    desc:'Cross-franchise character import adapted to Brawlhalla\'s physics-based combat, with a full custom moveset.',
    tags:['Character Import','Moveset','Skin'],
    software:['Blender','Substance Painter'],
    materials:['Stylized toon shader', 'Custom particle trail'],
    animations:['Full attack chain','Idle + taunt set'],
    c1:'#F97316', c2:'#7c2d12', icon:ICONS.brawlhalla,
  },
  {
    id:'laura-trails', title:'Laura (Trails)', game:'ror2', gameName:'Risk of Rain 2',
    desc:'Survivor import rebuilt as a fully playable Risk of Rain 2 character, tuned for run-based balance.',
    tags:['Character Import','Moveset','Bug Fixes'],
    software:['Unity','Blender','Rider'],
    materials:['Custom material pass','Item-proc VFX'],
    animations:['Full survivor animation set'],
    c1:'#a855f7', c2:'#3b0764', icon:ICONS.ror2,
  },
  {
    id:'borderlands-allies', title:'Borderlands Allies', game:'borderlands', gameName:'Borderlands',
    desc:'A companion/ally system adding recruitable allies with their own loadouts, barks, and combat AI.',
    tags:['Custom Fighter','UI','Bug Fixes'],
    software:['UE Editor','Blender'],
    materials:['Faction-matched texture kit'],
    animations:['Combat + traversal animation set'],
    c1:'#facc15', c2:'#713f12', icon:ICONS.borderlands,
  },
  {
    id:'amy-rose', title:'Amy Rose', game:'skyrim', gameName:'Skyrim',
    desc:'Fully voiced custom follower import with a matching outfit set and compatibility patching for major overhauls.',
    tags:['Character Import','Skin','Bug Fixes'],
    software:['Creation Kit','Nifskope','Photoshop'],
    materials:['Custom armor texture set'],
    animations:['Custom idle + combat behavior'],
    c1:'#3B82F6', c2:'#1e3a8a', icon:ICONS.skyrim,
  },
  {
    id:'stellar-blade', title:'Stellar Blade', game:'re', gameName:'Resident Evil',
    desc:'High-fidelity character import reworked to fit Resident Evil\'s engine, lighting, and animation rig.',
    tags:['Character Import','Skin','Animations'],
    software:['Blender','Substance Painter','RE Engine tools'],
    materials:['PBR skin + cloth material set'],
    animations:['Rig retarget','12 custom animations'],
    c1:'#dc2626', c2:'#450a0a', icon:ICONS.re,
  },
];

/* ---------- TESTIMONIALS (Discord) ---------- */
const TESTIMONIALS = [
  { name:'Kael#0192', tag:'via Discord', stars:5, quote:'Commissioned a full custom fighter for Smash Ultimate. Got hitbox-accurate frame data and a moveset that actually felt unique, not copy-pasted.' },
  { name:'Rowan.exe', tag:'via Discord', stars:5, quote:'My Skyrim follower mod had NPC conflicts breaking quests. Fixed and repatched within two days with a clear explanation of what went wrong.' },
  { name:'vexthorne', tag:'via Discord', stars:5, quote:'Asked for a Risk of Rain 2 survivor import and got full animations, VFX, and balance tuning. Way more polished than I expected for the price.' },
  { name:'mossy_lantern', tag:'via Discord', stars:5, quote:'Clean communication the whole way through my Borderlands ally commission. Sent progress clips at every milestone.' },
  { name:'Junko.k', tag:'via Discord', stars:4, quote:'Great Brawlhalla moveset work. One round of revisions needed for hit timing, handled fast and without extra charge.' },
  { name:'ashgrove', tag:'via Discord', stars:5, quote:'Resident Evil character import looked AAA-quality. The lighting and material work matched the base game perfectly.' },
];

/* ==========================================================
   BEHAVIOR
========================================================== */
document.addEventListener('DOMContentLoaded', () => {

  /* ---- mobile menu ---- */
  const burger = document.getElementById('burger');
  const mobileMenu = document.getElementById('mobileMenu');
  if(burger && mobileMenu){
    burger.addEventListener('click', () => mobileMenu.classList.toggle('open'));
    mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => mobileMenu.classList.remove('open')));
  }

  /* ---- active nav link ---- */
  const path = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .mobile-menu a').forEach(a => {
    if(a.getAttribute('href') === path) a.classList.add('active');
  });

  /* ---- scroll reveal ---- */
  const revealEls = document.querySelectorAll('.reveal');
  if('IntersectionObserver' in window && revealEls.length){
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold:.12 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in'));
  }

  /* ---- render featured games (home) ---- */
  const gameGrid = document.getElementById('gameGrid');
  if(gameGrid){
    GAMES.forEach(g => {
      const el = document.createElement('div');
      el.className = 'game-tile glass reveal';
      el.innerHTML = `<div class="g-icon" style="color:${g.color}">${g.icon}</div><div class="g-name">${g.name}</div>`;
      gameGrid.appendChild(el);
    });
  }

  /* ---- render "what I create" (home) ---- */
  const createGrid = document.getElementById('createGrid');
  if(createGrid){
    CREATE_ITEMS.forEach(c => {
      const el = document.createElement('div');
      el.className = 'create-card glass reveal';
      el.innerHTML = `<div class="create-icon" style="color:var(--blue)">${c.icon}</div><h3>${c.title}</h3><p>${c.desc}</p>`;
      createGrid.appendChild(el);
    });
  }

  /* ---- render recent projects (home, no filtering, first 6) ---- */
  const recentGrid = document.getElementById('recentGrid');
  if(recentGrid){
    PROJECTS.forEach(p => recentGrid.appendChild(buildProjectCard(p)));
  }

  /* ---- render full portfolio grid (portfolio.html, with filtering) ---- */
  const portfolioGrid = document.getElementById('portfolioGrid');
  if(portfolioGrid){
    const filterBar = document.getElementById('filterBar');
    const cats = ['all', ...new Set(PROJECTS.map(p => p.game))];
    const catNames = { all:'All Projects' };
    PROJECTS.forEach(p => catNames[p.game] = p.gameName);

    cats.forEach(cat => {
      const btn = document.createElement('button');
      btn.className = 'filter-btn' + (cat === 'all' ? ' active' : '');
      btn.textContent = catNames[cat];
      btn.dataset.cat = cat;
      btn.addEventListener('click', () => {
        filterBar.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderPortfolio(cat);
      });
      filterBar.appendChild(btn);
    });

    function renderPortfolio(cat){
      portfolioGrid.innerHTML = '';
      const list = cat === 'all' ? PROJECTS : PROJECTS.filter(p => p.game === cat);
      list.forEach(p => portfolioGrid.appendChild(buildProjectCard(p)));
    }
    renderPortfolio('all');
  }

  /* ---- render testimonials ---- */
  const testiGrid = document.getElementById('testiGrid');
  if(testiGrid){
    TESTIMONIALS.forEach(t => {
      const el = document.createElement('div');
      el.className = 'testi-card glass reveal';
      const initials = t.name.replace(/[^A-Za-z]/g,'').slice(0,2).toUpperCase();
      el.innerHTML = `
        <div class="testi-top">
          <div class="testi-avatar">${initials}</div>
          <div>
            <div class="testi-name">${t.name}</div>
            <div class="testi-tag">💬 ${t.tag}</div>
          </div>
        </div>
        <div class="testi-stars">${'★'.repeat(t.stars)}${'☆'.repeat(5-t.stars)}</div>
        <p class="testi-quote">"${t.quote}"</p>
      `;
      testiGrid.appendChild(el);
    });
  }

  /* ---- project modal ---- */
  const modalOverlay = document.getElementById('modalOverlay');
  if(modalOverlay){
    document.body.addEventListener('click', (e) => {
      const trigger = e.target.closest('[data-project]');
      if(trigger){
        e.preventDefault();
        openModal(trigger.dataset.project);
      }
      if(e.target === modalOverlay || e.target.closest('.modal-close')){
        modalOverlay.classList.remove('open');
      }
    });
    document.addEventListener('keydown', (e) => { if(e.key === 'Escape') modalOverlay.classList.remove('open'); });
  }

  function openModal(id){
    const p = PROJECTS.find(x => x.id === id);
    if(!p) return;
    modalOverlay.innerHTML = `
      <div class="modal-box">
        <button class="modal-close">✕</button>
        <div class="modal-thumb" style="--c1:${p.c1};--c2:${p.c2}">${p.icon}</div>
        <div class="modal-content">
          <div class="modal-game">${p.gameName}</div>
          <h3>${p.title}</h3>
          <p class="desc">${p.desc}</p>
          <div class="modal-grid">
            <div><h6>Included</h6><ul>${p.tags.map(t=>`<li>${t}</li>`).join('')}</ul></div>
            <div><h6>Software Used</h6><ul>${p.software.map(t=>`<li>${t}</li>`).join('')}</ul></div>
            <div><h6>Materials</h6><ul>${p.materials.map(t=>`<li>${t}</li>`).join('')}</ul></div>
            <div><h6>Animations</h6><ul>${p.animations.map(t=>`<li>${t}</li>`).join('')}</ul></div>
          </div>
          <a href="contact.html" class="btn btn-primary">Commission Something Like This</a>
        </div>
      </div>
    `;
    modalOverlay.classList.add('open');
  }

  /* ---- before/after slider ---- */
  document.querySelectorAll('.ba-slider').forEach(slider => {
    const handle = slider.querySelector('.ba-handle');
    const before = slider.querySelector('.ba-before');
    let dragging = false;

    function setPos(clientX){
      const rect = slider.getBoundingClientRect();
      let pct = ((clientX - rect.left) / rect.width) * 100;
      pct = Math.max(2, Math.min(98, pct));
      handle.style.left = pct + '%';
      before.style.clipPath = `inset(0 ${100-pct}% 0 0)`;
    }
    handle.addEventListener('mousedown', () => dragging = true);
    window.addEventListener('mouseup', () => dragging = false);
    window.addEventListener('mousemove', (e) => { if(dragging) setPos(e.clientX); });
    handle.addEventListener('touchstart', () => dragging = true, {passive:true});
    window.addEventListener('touchend', () => dragging = false);
    window.addEventListener('touchmove', (e) => { if(dragging) setPos(e.touches[0].clientX); }, {passive:true});
    slider.addEventListener('click', (e) => { if(e.target !== handle) setPos(e.clientX); });
  });

  /* ---- contact form: file input preview + submit feedback ---- */
  const fileInput = document.getElementById('refFiles');
  const fileList = document.getElementById('fileList');
  if(fileInput){
    fileInput.addEventListener('change', () => {
      const names = Array.from(fileInput.files).map(f => f.name);
      fileList.textContent = names.length ? `Attached: ${names.join(', ')}` : '';
    });
  }
  const commissionForm = document.getElementById('commissionForm');
  if(commissionForm){
    commissionForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = commissionForm.querySelector('button[type="submit"]');
      btn.textContent = 'Request Sent ✓';
      btn.style.background = 'linear-gradient(135deg, #22c55e, #16a34a)';
      commissionForm.querySelectorAll('input, select, textarea').forEach(f => f.disabled = true);
    });
  }
});

/* ---------- shared project card builder ---------- */
function buildProjectCard(p){
  const el = document.createElement('div');
  el.className = 'project-card glass reveal';
  el.innerHTML = `
    <div class="project-thumb" style="--c1:${p.c1};--c2:${p.c2}">
      <span class="badge">${p.gameName}</span>
      ${p.icon}
    </div>
    <div class="project-body">
      <h3>${p.title}</h3>
      <p>${p.desc}</p>
      <div class="project-tags">${p.tags.map(t => `<span class="chip">${t}</span>`).join('')}</div>
      <div class="project-footer">
        <a href="portfolio.html#${p.id}" class="view-link" data-project="${p.id}">View Project →</a>
      </div>
    </div>
  `;
  return el;
}
